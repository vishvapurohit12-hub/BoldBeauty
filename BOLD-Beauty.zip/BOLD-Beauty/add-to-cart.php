<?php

session_start();

require 'includes/database.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header("Location: shop.php");
    exit;
}

$stmt = $conn->prepare("
    SELECT id, stock
    FROM products
    WHERE id = ?
    AND status = 'active'
    LIMIT 1
");

$stmt->bind_param("i", $id);

$stmt->execute();

$product = $stmt->get_result()->fetch_assoc();

if ($product) {

    $stock = (int)$product['stock'];

    if ($stock > 0) {

        $currentQty = (int)(
            $_SESSION['cart'][$id] ?? 0
        );

        $newQty = $currentQty + 1;

        if ($newQty > $stock) {
            $newQty = $stock;
        }

        $_SESSION['cart'][$id] = $newQty;
    }
}

header("Location: cart.php");
exit;