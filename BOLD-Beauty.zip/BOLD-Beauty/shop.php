<?php

require 'includes/database.php';
require 'includes/functions.php';

$q = trim($_GET['q'] ?? '');
$sort = $_GET['sort'] ?? 'new';

$sql = "
    SELECT 
        p.*,
        c.name AS category_name
    FROM products p
    LEFT JOIN categories c 
        ON p.category_id = c.id
    WHERE p.status = 'active'
";

if ($q !== '') {

    $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)";

    if ($sort === 'low') {
        $sql .= " ORDER BY COALESCE(p.discount_price,p.price) ASC";
    } elseif ($sort === 'high') {
        $sql .= " ORDER BY COALESCE(p.discount_price,p.price) DESC";
    } else {
        $sql .= " ORDER BY p.id DESC";
    }

    $like = "%" . $q . "%";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();

    $rs = $stmt->get_result();

} else {

    if ($sort === 'low') {
        $sql .= " ORDER BY COALESCE(p.discount_price,p.price) ASC";
    } elseif ($sort === 'high') {
        $sql .= " ORDER BY COALESCE(p.discount_price,p.price) DESC";
    } else {
        $sql .= " ORDER BY p.id DESC";
    }

    $rs = $conn->query($sql);
}

$pageTitle = "Shop — BOLD Beauty";

require 'includes/header.php';

?>

<!-- PAGE HEADER -->

<section class="page-head py-5">

    <div class="container text-center">

        <p class="eyebrow">
            BOLD BEAUTY
        </p>

        <h1 class="section-title">
            Shop All
        </h1>

        <p class="text-muted">
            Discover your new beauty favourites.
        </p>

    </div>

</section>


<!-- SHOP -->

<div class="container py-5">

    <!-- SEARCH -->

    <form method="GET" class="row g-2 mb-5">

        <div class="col-md-6">

            <input
                type="text"
                name="q"
                value="<?= htmlspecialchars($q) ?>"
                class="form-control"
                placeholder="Search makeup..."
            >

        </div>

        <div class="col-md-4">

            <select
                name="sort"
                class="form-select"
            >

                <option
                    value="new"
                    <?= $sort === 'new' ? 'selected' : '' ?>
                >
                    Newest
                </option>

                <option
                    value="low"
                    <?= $sort === 'low' ? 'selected' : '' ?>
                >
                    Price: Low to High
                </option>

                <option
                    value="high"
                    <?= $sort === 'high' ? 'selected' : '' ?>
                >
                    Price: High to Low
                </option>

            </select>

        </div>

        <div class="col-md-2">

            <button
                type="submit"
                class="btn btn-bold w-100"
            >
                SEARCH
            </button>

        </div>

    </form>


    <!-- PRODUCTS -->

    <div class="row g-4">

        <?php if ($rs && $rs->num_rows > 0): ?>

            <?php while ($p = $rs->fetch_assoc()): ?>

                <?php

                $price = !empty($p['discount_price'])
                    ? $p['discount_price']
                    : $p['price'];

                ?>

                <div class="col-12 col-sm-6 col-lg-3">

                    <div class="product-card h-100">

                        <!-- IMAGE -->

                        <div
                            class="product-img"
                            style="
                                height:310px;
                                background:#f8f4f1;
                                overflow:hidden;
                                position:relative;
                            "
                        >

                            <img
                                src="<?= htmlspecialchars($p['image']) ?>"
                                alt="<?= htmlspecialchars($p['name']) ?>"
                                style="
                                    width:100%;
                                    height:100%;
                                    object-fit:cover;
                                    display:block;
                                "
                            >

                        </div>


                        <!-- DETAILS -->

                        <div class="p-3">

                            <?php if (!empty($p['category_name'])): ?>

                                <small class="text-muted">
                                    <?= htmlspecialchars($p['category_name']) ?>
                                </small>

                            <?php endif; ?>


                            <h5 class="mt-1 mb-2">

                                <?= htmlspecialchars($p['name']) ?>

                            </h5>


                            <!-- PRICE -->

                            <div class="mb-3">

                                <?php if (!empty($p['discount_price'])): ?>

                                    <span
                                        class="fw-bold"
                                        style="color:#8b1735;"
                                    >
                                        ₹<?= number_format($p['discount_price'], 2) ?>
                                    </span>

                                    <del
                                        class="text-muted ms-2"
                                    >
                                        ₹<?= number_format($p['price'], 2) ?>
                                    </del>

                                <?php else: ?>

                                    <span class="fw-bold">
                                        ₹<?= number_format($p['price'], 2) ?>
                                    </span>

                                <?php endif; ?>

                            </div>


                            <!-- VIEW PRODUCT -->

                            <a
    href="product.php?id=<?= (int)$p['id'] ?>"
    class="btn btn-outline-dark w-100 mb-2"
>
    VIEW PRODUCT
</a>


                            <!-- ADD TO CART -->

                            <?php if ((int)$p['stock'] > 0): ?>

                                <a
                                    href="add-to-cart.php?id=<?= (int)$p['id'] ?>"
                                    class="btn btn-bold w-100"
                                >
                                    ADD TO CART
                                </a>

                            <?php else: ?>

                                <button
                                    class="btn btn-secondary w-100"
                                    disabled
                                >
                                    OUT OF STOCK
                                </button>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="col-12 text-center py-5">

                <h3>
                    No products found.
                </h3>

                <p class="text-muted">
                    Try another search.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>


<?php require 'includes/footer.php'; ?>