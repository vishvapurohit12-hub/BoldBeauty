<?php

session_start();

require 'includes/database.php';
require 'includes/functions.php';

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header("Location: shop.php");
    exit;
}

$stmt = $conn->prepare("
    SELECT 
        p.*,
        c.name AS category_name
    FROM products p
    LEFT JOIN categories c
        ON p.category_id = c.id
    WHERE p.id = ?
    AND p.status = 'active'
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

$pageTitle = $product['name'];

require 'includes/header.php';

?>

<div class="container py-5">

    <div class="row g-5">

        <!-- PRODUCT IMAGE -->

        <div class="col-md-6">

            <div
                style="
                    background:#f8f4f1;
                    border-radius:12px;
                    overflow:hidden;
                "
            >

                <img
                    src="<?= e(img($product['image'])) ?>"
                    alt="<?= e($product['name']) ?>"
                    style="
                        width:100%;
                        height:550px;
                        object-fit:cover;
                        display:block;
                    "
                >

            </div>

        </div>


        <!-- PRODUCT INFORMATION -->

        <div class="col-md-6">

            <?php if (!empty($product['category_name'])): ?>

                <p class="eyebrow">
                    <?= e($product['category_name']) ?>
                </p>

            <?php endif; ?>


            <h1 class="section-title">
                <?= e($product['name']) ?>
            </h1>


            <!-- PRICE -->

            <div class="mb-3">

                <?php if (
                    !empty($product['discount_price']) &&
                    $product['discount_price'] > 0
                ): ?>

                    <span
                        style="
                            font-size:26px;
                            font-weight:bold;
                            color:#8b1735;
                        "
                    >
                        ₹<?= number_format(
                            $product['discount_price'],
                            2
                        ) ?>
                    </span>

                    <del
                        class="text-muted ms-2"
                        style="font-size:18px;"
                    >
                        ₹<?= number_format(
                            $product['price'],
                            2
                        ) ?>
                    </del>

                <?php else: ?>

                    <span
                        style="
                            font-size:26px;
                            font-weight:bold;
                        "
                    >
                        ₹<?= number_format(
                            $product['price'],
                            2
                        ) ?>
                    </span>

                <?php endif; ?>

            </div>


            <!-- DESCRIPTION -->

            <div class="mt-4">

                <h5>
                    Description
                </h5>

                <p>
                    <?= nl2br(e($product['description'])) ?>
                </p>

            </div>


            <!-- STOCK -->

            <?php if ((int)$product['stock'] > 0): ?>

                <p class="text-success">

                    ✓
                    <?= (int)$product['stock'] ?>
                    items available

                </p>


                <!-- QUANTITY -->

                <form
                    method="GET"
                    action="add-to-cart.php"
                    class="mt-4"
                >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int)$product['id'] ?>"
                    >

                    <label class="form-label fw-bold">
                        Quantity
                    </label>

                    <div
                        class="d-flex align-items-center gap-3 mb-3"
                    >

                        <input
                            type="number"
                            name="qty"
                            value="1"
                            min="1"
                            max="<?= (int)$product['stock'] ?>"
                            class="form-control"
                            style="width:100px;"
                        >

                    </div>


                    <!-- ADD TO CART -->

                    <button
                        type="submit"
                        class="btn btn-bold"
                    >
                        🛍 ADD TO CART
                    </button>


                    <!-- WISHLIST -->

                    <a
                        href="wishlist.php?add=<?= (int)$product['id'] ?>"
                        class="btn btn-outline-dark ms-2"
                    >
                        ♡ WISHLIST
                    </a>

                </form>


            <?php else: ?>

                <button
                    class="btn btn-secondary"
                    disabled
                >
                    OUT OF STOCK
                </button>

            <?php endif; ?>

        </div>

    </div>

</div>


<?php require 'includes/footer.php'; ?>