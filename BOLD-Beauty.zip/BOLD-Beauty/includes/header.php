<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/functions.php';

$pageTitle = $pageTitle ?? 'BOLD Beauty';

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($pageTitle) ?> - BOLD Beauty</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="/BOLD-Beauty/assets/css/style.css"
    >

</head>

<body>

<nav class="navbar navbar-expand-lg bg-white border-bottom">

    <div class="container">

        <a
            class="navbar-brand brand"
            href="/BOLD-Beauty/index.php"
        >
            BOLD<span>Beauty</span>
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNav"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            class="collapse navbar-collapse"
            id="mainNav"
        >

            <ul class="navbar-nav ms-auto align-items-lg-center">

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="/BOLD-Beauty/index.php"
                    >
                        Home
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="/BOLD-Beauty/shop.php"
                    >
                        Shop
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="/BOLD-Beauty/wishlist.php"
                    >
                        Wishlist
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="/BOLD-Beauty/cart.php"
                    >
                        Cart
                    </a>
                </li>

                <?php if (isset($_SESSION['user_id'])): ?>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="/BOLD-Beauty/orders.php"
                        >
                            My Orders
                        </a>
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="/BOLD-Beauty/logout.php"
                        >
                            Logout
                        </a>
                    </li>

                <?php else: ?>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="/BOLD-Beauty/login.php"
                        >
                            Login
                        </a>
                    </li>

                <?php endif; ?>

            </ul>

        </div>

    </div>

</nav>

<main>