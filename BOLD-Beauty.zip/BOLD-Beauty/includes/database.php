<?php
$c=new mysqli("localhost","root","","bold_beauty"); if($c->connect_error) die("Database connection failed. Run setup.php first."); $c->set_charset("utf8mb4"); $conn=$c;
