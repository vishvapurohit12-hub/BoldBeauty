<?php
if(session_status()===PHP_SESSION_NONE)session_start();
function e($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function customer(){return !empty($_SESSION['user_id'])&&($_SESSION['role']??'')==='customer';}
function admin(){return !empty($_SESSION['admin_id'])&&($_SESSION['role']??'')==='admin';}
function needCustomer(){if(!customer()){header('Location: login.php');exit;}}
function needAdmin(){if(!admin()){header('Location: login.php');exit;}}
function go($u){header('Location: '.$u);exit;}
function price($p){return (float)($p['discount_price']?:$p['price']);}
function img($x){return $x?:'assets/images/product-placeholder.svg';}
function cc(){return array_sum($_SESSION['cart']??[]);}
function wc(){return count($_SESSION['wishlist']??[]);}
