<?php

if (!function_exists('productCard')) {

    function productCard($p)
    {
        $name = strtolower(trim($p['name'] ?? 'product'));

        /*
        |--------------------------------------------------------------------------
        | Product ID
        |--------------------------------------------------------------------------
        */

        $id = (int)($p['id'] ?? 0);

        /*
        |--------------------------------------------------------------------------
        | Product Image
        |--------------------------------------------------------------------------
        */

        $img = $p['image'] ?? '';

        // If database image is empty, use online image
        if (empty($img)) {

            $img = 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&auto=format&fit=crop';

            if (strpos($name, 'mascara') !== false) {

                $img = 'https://images.unsplash.com/photo-1631214524020-7e18db9a8f92?w=800&auto=format&fit=crop';

            } elseif (strpos($name, 'concealer') !== false) {

                $img = 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=800&auto=format&fit=crop';

            } elseif (strpos($name, 'blush') !== false) {

                $img = 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=800&auto=format&fit=crop';

            } elseif (strpos($name, 'foundation') !== false) {

                $img = 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&auto=format&fit=crop';

            } elseif (
                strpos($name, 'lipstick') !== false ||
                strpos($name, 'lip stick') !== false
            ) {

                $img = 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=800&auto=format&fit=crop';

            } elseif (
                strpos($name, 'lip gloss') !== false ||
                strpos($name, 'gloss') !== false
            ) {

                $img = 'https://images.unsplash.com/photo-1619451334792-150fd785ee74?w=800&auto=format&fit=crop';

            } elseif (
                strpos($name, 'eyeshadow') !== false ||
                strpos($name, 'eye shadow') !== false ||
                strpos($name, 'palette') !== false
            ) {

                $img = 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=800&auto=format&fit=crop';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Price
        |--------------------------------------------------------------------------
        */

        $price = (
            isset($p['discount_price']) &&
            $p['discount_price'] !== null &&
            $p['discount_price'] !== ''
        )
            ? $p['discount_price']
            : ($p['price'] ?? 0);

        /*
        |--------------------------------------------------------------------------
        | Safe Output
        |--------------------------------------------------------------------------
        */

        $safeName = htmlspecialchars(
            $p['name'] ?? 'Product',
            ENT_QUOTES,
            'UTF-8'
        );

        $safeImage = htmlspecialchars(
            $img,
            ENT_QUOTES,
            'UTF-8'
        );

        /*
        |--------------------------------------------------------------------------
        | Product Card
        |--------------------------------------------------------------------------
        */

        echo '
        <div class="col-6 col-md-4 col-lg-3 mb-4">

            <div class="card product-card h-100 border-0 shadow-sm">

                <a href="product.php?id=' . $id . '"
                   class="text-decoration-none">

                    <img
                        src="' . $safeImage . '"
                        class="card-img-top product-image"
                        alt="' . $safeName . '"
                        loading="lazy"
                        style="
                            width:100%;
                            height:300px;
                            object-fit:cover;
                        "
                    >

                </a>

                <div class="card-body text-center">

                    <h5 class="card-title">
                        ' . $safeName . '
                    </h5>

                    <p class="fw-bold mb-3">
                        ₹' . number_format((float)$price, 2) . '
                    </p>

                    <a
                        href="product.php?id=' . $id . '"
                        class="btn btn-dark btn-sm px-4"
                    >
                        View Product
                    </a>

                </div>

            </div>

        </div>';
    }
}
?>