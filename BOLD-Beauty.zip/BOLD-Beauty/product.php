<?php

require 'includes/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("
    SELECT p.*, c.name AS category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    require 'includes/header.php';

    echo '
    <div class="container py-5 text-center">
        <h2>Product Not Found</h2>
        <p>The product you are looking for does not exist.</p>
        <a href="shop.php" class="btn btn-dark">Back to Shop</a>
    </div>';

    require 'includes/footer.php';
    exit;
}

$pageTitle = $product['name'];

require 'includes/header.php';

$imageValue = trim($product['image'] ?? '');

$image = 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800';

if ($imageValue !== '') {

    // If image is already an online URL
    if (filter_var($imageValue, FILTER_VALIDATE_URL)) {

        $image = $imageValue;

    } else {

        // Clean database image path
        $cleanImage = str_replace('\\', '/', $imageValue);
        $cleanImage = ltrim($cleanImage, '/');

        // Check different possible image locations
        $possibleFiles = [
            __DIR__ . '/' . $cleanImage,
            __DIR__ . '/assets/images/' . basename($cleanImage),
            __DIR__ . '/assets/uploads/' . basename($cleanImage),
            __DIR__ . '/images/' . basename($cleanImage),
            __DIR__ . '/uploads/' . basename($cleanImage)
        ];

        $possibleUrls = [
            $cleanImage,
            'assets/images/' . basename($cleanImage),
            'assets/uploads/' . basename($cleanImage),
            'images/' . basename($cleanImage),
            'uploads/' . basename($cleanImage)
        ];

        foreach ($possibleFiles as $index => $file) {

            if (file_exists($file)) {
                $image = $possibleUrls[$index];
                break;
            }

        }
    }
}
$finalPrice = (
    isset($product['discount_price']) &&
    $product['discount_price'] !== null &&
    $product['discount_price'] > 0
)
    ? $product['discount_price']
    : $product['price'];

?>

<div class="container py-5">

    <div class="row g-5">

        <div class="col-md-6">

            <img
                src="<?= htmlspecialchars($image) ?>"
                alt="<?= htmlspecialchars($product['name']) ?>"
                class="img-fluid rounded shadow-sm"
                style="width:100%; height:500px; object-fit:cover;"
            >

        </div>

        <div class="col-md-6">

            <p class="text-muted">
                <?= htmlspecialchars($product['category_name'] ?? 'Beauty') ?>
            </p>

            <h1 class="mb-3">
                <?= htmlspecialchars($product['name']) ?>
            </h1>

            <h2 class="mb-4">
                ₹<?= number_format($finalPrice, 2) ?>
            </h2>

            <?php if (
                isset($product['discount_price']) &&
                $product['discount_price'] !== null &&
                $product['discount_price'] > 0 &&
                $product['discount_price'] < $product['price']
            ): ?>

                <p class="text-muted">
                    <del>₹<?= number_format($product['price'], 2) ?></del>
                </p>

            <?php endif; ?>

            <?php if (!empty($product['description'])): ?>

                <h5>Description</h5>

                <p class="text-muted">
                    <?= nl2br(htmlspecialchars($product['description'])) ?>
                </p>

            <?php endif; ?>

            <p class="mt-4">
                <strong>Stock:</strong>

                <?php if ((int)$product['stock'] > 0): ?>

                    <span class="text-success">
                        In Stock
                    </span>

                <?php else: ?>

                    <span class="text-danger">
                        Out of Stock
                    </span>

                <?php endif; ?>
            </p>

            <?php if ((int)$product['stock'] > 0): ?>

                <a
                    href="cart.php?id=<?= (int)$product['id'] ?>"
                    class="btn btn-dark btn-lg mt-3"
                >
                    Add to Cart
                </a>

            <?php else: ?>

                <button
                    class="btn btn-secondary btn-lg mt-3"
                    disabled
                >
                    Out of Stock
                </button>

            <?php endif; ?>

            <a
                href="shop.php"
                class="btn btn-outline-dark btn-lg mt-3 ms-2"
            >
                Back to Shop
            </a>

        </div>

    </div>

</div>

<?php require 'includes/footer.php'; ?>