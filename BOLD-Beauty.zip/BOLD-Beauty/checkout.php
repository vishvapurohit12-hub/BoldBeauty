<?php

session_start();

require 'includes/database.php';
require 'includes/functions.php';

needCustomer();

if (empty($_SESSION['cart'])) {
    go('cart.php');
}


/* =========================
   GET CART PRODUCTS
========================= */

$items = [];
$subtotal = 0;

$ids = array_keys($_SESSION['cart']);

$ids = array_map('intval', $ids);

$in = implode(',', $ids);

$result = $conn->query("
    SELECT *
    FROM products
    WHERE id IN ($in)
    AND status = 'active'
");

while ($product = $result->fetch_assoc()) {

    $id = (int)$product['id'];

    $qty = (int)($_SESSION['cart'][$id] ?? 0);

    if ($qty <= 0) {
        continue;
    }

    /* Make sure quantity does not exceed stock */

    if ($qty > (int)$product['stock']) {
        $qty = (int)$product['stock'];
    }

    if ($qty <= 0) {
        continue;
    }

    $unitPrice = price($product);

    $lineTotal = $unitPrice * $qty;

    $product['qty'] = $qty;
    $product['line'] = $lineTotal;

    $subtotal += $lineTotal;

    $items[] = $product;
}


/* =========================
   DELIVERY
========================= */

$delivery = ($subtotal >= 999) ? 0 : 49;

$total = $subtotal + $delivery;

$error = "";


/* =========================
   PLACE ORDER
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $pincode = trim($_POST['pincode'] ?? '');
    $payment = trim($_POST['payment'] ?? 'COD');


    /* VALIDATION */

    if (
        $name === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $address === '' ||
        $city === '' ||
        $pincode === ''
    ) {

        $error = "Please fill all required fields correctly.";

    } elseif (empty($items)) {

        $error = "Your cart is empty.";

    } else {

        /*
        Generate order number
        */

        $orderNumber =
            'BOLD' .
            date('YmdHis') .
            rand(10, 99);


        $userId = (int)$_SESSION['user_id'];


        /*
        IMPORTANT:
        Start transaction.
        This means if something fails,
        the order won't be partially saved.
        */

        $conn->begin_transaction();


        try {

            /* =========================
               INSERT ORDER
            ========================= */

            $stmt = $conn->prepare("
                INSERT INTO orders
                (
                    user_id,
                    order_number,
                    subtotal,
                    delivery,
                    total,
                    name,
                    email,
                    phone,
                    address,
                    city,
                    pincode,
                    payment_method,
                    order_status
                )
                VALUES
                (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            ");


            if (!$stmt) {
                throw new Exception(
                    "Order prepare failed: " .
                    $conn->error
                );
            }


            $orderStatus = 'Pending';


            $stmt->bind_param(
                "isdddssssssss",
                $userId,
                $orderNumber,
                $subtotal,
                $delivery,
                $total,
                $name,
                $email,
                $phone,
                $address,
                $city,
                $pincode,
                $payment,
                $orderStatus
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "Order insert failed: " .
                    $stmt->error
                );
            }


            $orderId = $conn->insert_id;


            /* =========================
               INSERT ORDER ITEMS
            ========================= */

            foreach ($items as $product) {

                $productId = (int)$product['id'];

                $productName = $product['name'];

                $productPrice = price($product);

                $quantity = (int)$product['qty'];


                $itemStmt = $conn->prepare("
                    INSERT INTO order_items
                    (
                        order_id,
                        product_id,
                        product_name,
                        price,
                        quantity
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");


                if (!$itemStmt) {

                    throw new Exception(
                        "Order item prepare failed: " .
                        $conn->error
                    );
                }


                $itemStmt->bind_param(
                    "iisdi",
                    $orderId,
                    $productId,
                    $productName,
                    $productPrice,
                    $quantity
                );


                if (!$itemStmt->execute()) {

                    throw new Exception(
                        "Order item insert failed: " .
                        $itemStmt->error
                    );
                }


                /* =========================
                   REDUCE STOCK
                ========================= */

                $stockStmt = $conn->prepare("
                    UPDATE products
                    SET stock = GREATEST(stock - ?, 0)
                    WHERE id = ?
                ");


                $stockStmt->bind_param(
                    "ii",
                    $quantity,
                    $productId
                );


                if (!$stockStmt->execute()) {

                    throw new Exception(
                        "Stock update failed: " .
                        $stockStmt->error
                    );
                }
            }


            /* =========================
               EVERYTHING SUCCESSFUL
            ========================= */

            $conn->commit();


            /* Empty cart */

            $_SESSION['cart'] = [];


            /* Go to success page */

            go(
                'order-success.php?order=' .
                urlencode($orderNumber)
            );

        } catch (Exception $e) {

            /*
            Undo everything if something failed
            */

            $conn->rollback();

            $error = $e->getMessage();
        }
    }
}


$pageTitle = 'Checkout';

require 'includes/header.php';

?>


<div class="container py-5">

    <h1 class="section-title mb-4">
        Checkout
    </h1>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">

            <?= e($error) ?>

        </div>

    <?php endif; ?>


    <div class="row g-4">


        <!-- CHECKOUT FORM -->

        <div class="col-lg-7">

            <div class="card p-4">

                <h4 class="mb-4">
                    Delivery Details
                </h4>


                <form method="POST">


                    <input
                        type="text"
                        name="name"
                        class="form-control mb-3"
                        placeholder="Full Name"
                        value="<?= e($_POST['name'] ?? '') ?>"
                        required
                    >


                    <input
                        type="email"
                        name="email"
                        class="form-control mb-3"
                        placeholder="Email"
                        value="<?= e(
                            $_POST['email']
                            ?? ($_SESSION['user_email'] ?? '')
                        ) ?>"
                        required
                    >


                    <input
                        type="text"
                        name="phone"
                        class="form-control mb-3"
                        placeholder="Mobile Number"
                        value="<?= e($_POST['phone'] ?? '') ?>"
                    >


                    <textarea
                        name="address"
                        class="form-control mb-3"
                        placeholder="Full Address"
                        rows="4"
                        required
                    ><?= e($_POST['address'] ?? '') ?></textarea>


                    <div class="row">

                        <div class="col-md-6">

                            <input
                                type="text"
                                name="city"
                                class="form-control mb-3"
                                placeholder="City"
                                value="<?= e($_POST['city'] ?? '') ?>"
                                required
                            >

                        </div>


                        <div class="col-md-6">

                            <input
                                type="text"
                                name="pincode"
                                class="form-control mb-3"
                                placeholder="Pincode"
                                value="<?= e($_POST['pincode'] ?? '') ?>"
                                required
                            >

                        </div>

                    </div>


                    <select
                        name="payment"
                        class="form-select mb-3"
                    >

                        <option value="COD">
                            Cash on Delivery
                        </option>

                        <option value="UPI">
                            UPI
                        </option>

                        <option value="Card">
                            Card
                        </option>

                    </select>


                    <button
                        type="submit"
                        class="btn btn-bold w-100"
                    >
                        PLACE ORDER
                    </button>


                </form>

            </div>

        </div>


        <!-- ORDER SUMMARY -->

        <div class="col-lg-5">

            <div class="card p-4">

                <h4 class="mb-4">
                    Order Summary
                </h4>


                <?php foreach ($items as $product): ?>

                    <div
                        class="d-flex justify-content-between mb-3"
                    >

                        <span>

                            <?= e($product['name']) ?>

                            × <?= (int)$product['qty'] ?>

                        </span>


                        <strong>

                            ₹<?= number_format(
                                $product['line'],
                                2
                            ) ?>

                        </strong>

                    </div>

                <?php endforeach; ?>


                <hr>


                <div class="d-flex justify-content-between">

                    <span>
                        Subtotal
                    </span>

                    <strong>
                        ₹<?= number_format(
                            $subtotal,
                            2
                        ) ?>
                    </strong>

                </div>


                <div class="d-flex justify-content-between mt-2">

                    <span>
                        Delivery
                    </span>

                    <strong>

                        <?= $delivery == 0
                            ? 'FREE'
                            : '₹' . number_format(
                                $delivery,
                                2
                            )
                        ?>

                    </strong>

                </div>


                <hr>


                <div class="d-flex justify-content-between">

                    <h4>
                        Total
                    </h4>

                    <h4>

                        ₹<?= number_format(
                            $total,
                            2
                        ) ?>

                    </h4>

                </div>

            </div>

        </div>

    </div>

</div>


<?php require 'includes/footer.php'; ?>