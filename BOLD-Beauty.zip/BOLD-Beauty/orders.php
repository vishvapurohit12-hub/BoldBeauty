<?php

session_start();

require 'includes/database.php';
require 'includes/functions.php';

needCustomer();


$stmt = $conn->prepare("
    SELECT *
    FROM orders
    WHERE user_id = ?
    ORDER BY id DESC
");

$stmt->bind_param(
    "i",
    $_SESSION['user_id']
);

$stmt->execute();

$result = $stmt->get_result();


$pageTitle = "My Orders";

require 'includes/header.php';

?>

<div class="container py-5">

    <h1 class="section-title mb-4">
        My Orders
    </h1>


    <?php if ($result->num_rows === 0): ?>

        <div class="text-center py-5">

            <h3>
                You haven't placed any orders yet.
            </h3>

            <a
                href="shop.php"
                class="btn btn-bold mt-3"
            >
                START SHOPPING
            </a>

        </div>


    <?php else: ?>


        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>

                        <th>
                            Order
                        </th>

                        <th>
                            Total
                        </th>

                        <th>
                            Payment
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Date
                        </th>

                    </tr>

                </thead>


                <tbody>

                <?php while ($order = $result->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= e($order['order_number']) ?>
                        </td>

                        <td>
                            ₹<?= number_format(
                                (float)$order['total'],
                                2
                            ) ?>
                        </td>

                        <td>
                            <?= e(
                                $order['payment_method']
                            ) ?>
                        </td>

                        <td>

                            <span class="badge bg-dark">

                                <?= e(
                                    $order['order_status']
                                ) ?>

                            </span>

                        </td>

                        <td>
                            <?= e(
                                $order['created_at']
                            ) ?>
                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</div>

<?php require 'includes/footer.php'; ?>