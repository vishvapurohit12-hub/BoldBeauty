<?php

require 'includes/database.php';
require 'includes/functions.php';

$rs = $conn->query("
    SELECT 
        p.*,
        c.name AS category_name
    FROM products p
    LEFT JOIN categories c 
        ON p.category_id = c.id
    WHERE p.status = 'active'
    ORDER BY p.id DESC
    LIMIT 8
");

$pageTitle = 'BOLD Beauty';

require 'includes/header.php';

?>

<!-- HERO SECTION -->

<section class="hero">

    <div class="container">

        <div class="row align-items-center">

            <!-- TEXT -->

            <div class="col-lg-7">

                <p class="eyebrow">
                    BOLD BEAUTY
                </p>

                <h1>
                    Makeup for your boldest self.
                </h1>

                <p class="lead">
                    Color, confidence and creativity for every version of you.
                </p>

                <a
                    class="btn btn-bold"
                    href="shop.php"
                >
                    SHOP NOW
                </a>

            </div>


            <!-- HERO IMAGE -->

            <div class="col-lg-5">

                <img
                    src="assets/images/hero-makeup.png"
                    alt="BOLD Beauty Makeup Collection"
                    class="hero-image"
                >

            </div>

        </div>

    </div>

</section>


<!-- FEATURED PRODUCTS -->

<div class="container py-5">

    <h2 class="section-title mb-4">
        Featured Beauty
    </h2>

    <div class="row g-4">

        <?php while ($p = $rs->fetch_assoc()): ?>

            <?php
            require 'includes/product-card.php';
            productCard($p);
            ?>

        <?php endwhile; ?>

    </div>

</div>


<?php require 'includes/footer.php'; ?>