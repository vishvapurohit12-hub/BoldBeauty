<?php

session_start();

require 'includes/database.php';
require 'includes/functions.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


/* REMOVE */

if (isset($_GET['remove'])) {

    $id = (int)$_GET['remove'];

    unset($_SESSION['cart'][$id]);

    header("Location: cart.php");
    exit;
}


/* UPDATE CART */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    foreach ($_POST['qty'] ?? [] as $id => $qty) {

        $id = (int)$id;
        $qty = (int)$qty;

        if ($qty <= 0) {

            unset($_SESSION['cart'][$id]);

            continue;
        }

        $stmt = $conn->prepare("
            SELECT stock
            FROM products
            WHERE id = ?
            AND status = 'active'
            LIMIT 1
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $product = $stmt->get_result()->fetch_assoc();

        if ($product) {

            $stock = (int)$product['stock'];

            $_SESSION['cart'][$id] = min(
                $qty,
                $stock
            );
        }
    }

    header("Location: cart.php");
    exit;
}


/* GET PRODUCTS */

$items = [];

$subtotal = 0;

$ids = array_keys($_SESSION['cart']);

if (!empty($ids)) {

    $ids = array_map('intval', $ids);

    $in = implode(',', $ids);

    $result = $conn->query("
        SELECT *
        FROM products
        WHERE id IN ($in)
        AND status = 'active'
    ");

    while ($product = $result->fetch_assoc()) {

        $id = (int)$product['id'];

        $qty = (int)(
            $_SESSION['cart'][$id] ?? 0
        );

        if ($qty <= 0) {
            continue;
        }


        /* PRICE */

        if (
            isset($product['discount_price']) &&
            $product['discount_price'] !== null &&
            $product['discount_price'] !== '' &&
            (float)$product['discount_price'] > 0
        ) {

            $unitPrice = (float)$product['discount_price'];

        } else {

            $unitPrice = (float)$product['price'];
        }


        /* LINE TOTAL */

        $lineTotal = $unitPrice * $qty;

        $subtotal += $lineTotal;


        $product['qty'] = $qty;

        $product['unit_price'] = $unitPrice;

        $product['line_total'] = $lineTotal;

        $items[] = $product;
    }
}


$pageTitle = "Your Cart";

require 'includes/header.php';

?>

<div class="container py-5">

    <h1 class="section-title mb-4">
        Your Cart
    </h1>


    <?php if (empty($items)): ?>

        <div class="text-center py-5">

            <h3>
                Your cart is empty.
            </h3>

            <p class="text-muted">
                Add some beauty products to your cart.
            </p>

            <a
                href="shop.php"
                class="btn btn-bold"
            >
                SHOP PRODUCTS
            </a>

        </div>

    <?php else: ?>


        <form method="POST">

            <div class="table-responsive">

                <table class="table align-middle">

                    <thead>

                        <tr>

                            <th>Product</th>

                            <th>Price</th>

                            <th>Quantity</th>

                            <th>Total</th>

                            <th></th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($items as $product): ?>

                        <tr>


                            <!-- PRODUCT -->

                            <td>

                                <div
                                    class="d-flex align-items-center gap-3"
                                >

                                    <img
                                        src="<?= e(img($product['image'])) ?>"
                                        width="75"
                                        height="75"
                                        style="
                                            object-fit:cover;
                                            border-radius:8px;
                                        "
                                    >

                                    <strong>
                                        <?= e($product['name']) ?>
                                    </strong>

                                </div>

                            </td>


                            <!-- PRICE -->

                            <td>

                                ₹<?= number_format(
                                    $product['unit_price'],
                                    2
                                ) ?>

                            </td>


                            <!-- QUANTITY -->

                            <td>

                                <div
                                    class="d-flex align-items-center"
                                    style="width:140px;"
                                >

                                    <button
                                        type="button"
                                        class="btn btn-outline-dark"
                                        onclick="changeQty(
                                            <?= (int)$product['id'] ?>,
                                            -1
                                        )"
                                    >
                                        −
                                    </button>


                                    <input
                                        id="qty-<?= (int)$product['id'] ?>"
                                        type="number"
                                        name="qty[<?= (int)$product['id'] ?>]"
                                        value="<?= (int)$product['qty'] ?>"
                                        min="1"
                                        max="<?= (int)$product['stock'] ?>"
                                        class="form-control text-center"
                                    >


                                    <button
                                        type="button"
                                        class="btn btn-outline-dark"
                                        onclick="changeQty(
                                            <?= (int)$product['id'] ?>,
                                            1
                                        )"
                                    >
                                        +
                                    </button>

                                </div>

                            </td>


                            <!-- LINE TOTAL -->

                            <td>

                                <strong
                                    id="total-<?= (int)$product['id'] ?>"
                                    data-price="<?= $product['unit_price'] ?>"
                                >

                                    ₹<?= number_format(
                                        $product['line_total'],
                                        2
                                    ) ?>

                                </strong>

                            </td>


                            <!-- REMOVE -->

                            <td>

                                <a
                                    href="cart.php?remove=<?= (int)$product['id'] ?>"
                                    class="text-danger"
                                >
                                    Remove
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>


            <button
                type="submit"
                class="btn btn-outline-dark"
            >
                UPDATE CART
            </button>

        </form>


        <div class="text-end mt-4">

            <h3>

                Subtotal:
                ₹<?= number_format($subtotal, 2) ?>

            </h3>

            <a
                href="checkout.php"
                class="btn btn-bold mt-2"
            >
                PROCEED TO CHECKOUT
            </a>

        </div>


    <?php endif; ?>

</div>


<script>

function changeQty(id, change) {

    const input =
        document.getElementById('qty-' + id);

    if (!input) return;


    let quantity =
        parseInt(input.value) || 1;


    const max =
        parseInt(input.max) || 999;


    quantity += change;


    if (quantity < 1) {
        quantity = 1;
    }


    if (quantity > max) {
        quantity = max;
    }


    input.value = quantity;


    const total =
        document.getElementById('total-' + id);

    const price =
        parseFloat(total.dataset.price);


    const newTotal =
        price * quantity;


    total.innerHTML =
        '₹' + newTotal.toFixed(2);
}

</script>


<?php require 'includes/footer.php'; ?>