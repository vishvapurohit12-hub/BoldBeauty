CREATE DATABASE IF NOT EXISTS bold_beauty; USE bold_beauty; -- Use setup.php for the complete schema and admin seed.
