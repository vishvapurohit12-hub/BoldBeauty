<?php
require 'includes/database.php';
require 'includes/functions.php';

if (!isset($_SESSION['wishlist'])) {
    $_SESSION['wishlist'] = [];
}

if (isset($_GET['add'])) {
    $_SESSION['wishlist'][(int)$_GET['add']] = 1;
    go('wishlist.php');
}

if (isset($_GET['remove'])) {
    unset($_SESSION['wishlist'][(int)$_GET['remove']]);
    go('wishlist.php');
}

$items = [];
$ids = array_keys($_SESSION['wishlist']);

if ($ids) {
    $in = implode(',', array_map('intval', $ids));

    $rs = $conn->query("
        SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id IN ($in)
    ");

    while ($x = $rs->fetch_assoc()) {
        $items[] = $x;
    }
}

$pageTitle = 'Wishlist';

require 'includes/header.php';
?>

<style>
.product-img {
    width: 100%;
    height: 310px;
    background: #f8f4f1;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.product-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}
</style>

<div class="container py-5">

    <h1 class="section-title">
        My Wishlist
    </h1>

    <div class="row g-4 mt-2">

        <?php if (!$items): ?>

            <div class="col-12 text-center py-5">

                <h3>No saved products yet.</h3>

                <a
                    class="btn btn-bold"
                    href="shop.php"
                >
                    EXPLORE PRODUCTS
                </a>

            </div>

        <?php else: ?>

            <?php foreach ($items as $p): ?>

                <div class="col-12 col-sm-6 col-lg-3">

                    <div class="product-card h-100">

                        <div class="product-img">

                            <img
                                src="<?= e(img($p['image'])) ?>"
                                alt="<?= e($p['name']) ?>"
                            >

                        </div>

                        <div class="p-3">

                            <?php if (!empty($p['category_name'])): ?>

                                <small class="text-muted">
                                    <?= e($p['category_name']) ?>
                                </small>

                            <?php endif; ?>

                            <h5 class="mt-1">
                                <?= e($p['name']) ?>
                            </h5>

                            <p class="fw-bold">
                                ₹<?= number_format(price($p), 2) ?>
                            </p>

                            <a
                                class="btn btn-dark w-100"
                                href="product-details.php?id=<?= (int)$p['id'] ?>"
                            >
                                VIEW
                            </a>

                            <a
                                class="btn btn-link text-danger w-100"
                                href="?remove=<?= (int)$p['id'] ?>"
                            >
                                Remove
                            </a>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>

<?php require 'includes/footer.php'; ?>