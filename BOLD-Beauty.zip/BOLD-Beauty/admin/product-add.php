<?php

require '../includes/database.php';
require '../includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$edit = $id > 0;

$p = [
    'name' => '',
    'description' => '',
    'price' => '',
    'discount_price' => '',
    'stock' => 0,
    'image' => '',
    'category_id' => '',
    'is_new' => 0,
    'is_best_seller' => 0,
    'status' => 'active'
];

/* Load product when editing */
if ($edit) {
    $s = $conn->prepare('SELECT * FROM products WHERE id = ?');
    $s->bind_param('i', $id);
    $s->execute();

    $result = $s->get_result();

    if ($result->num_rows > 0) {
        $p = $result->fetch_assoc();
    } else {
        header('Location: products.php');
        exit;
    }
}

$err = '';

/* Handle form submission */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);

    $disc = ($_POST['discount_price'] ?? '') === ''
        ? null
        : (float)$_POST['discount_price'];

    $stock = (int)($_POST['stock'] ?? 0);
    $cat = (int)($_POST['category_id'] ?? 0);

    $new = isset($_POST['is_new']) ? 1 : 0;
    $best = isset($_POST['is_best_seller']) ? 1 : 0;

    $status = $_POST['status'] ?? 'active';

    $image = $p['image'];

    /* Validation */
    if (!$name || $price <= 0 || !$cat) {
        $err = 'Name, price and category are required.';
    }

    /* Image upload */
    if (!$err && !empty($_FILES['image']['name'])) {

        $ext = strtolower(
            pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION)
        );

        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {

            $err = 'Use JPG, PNG, GIF or WEBP.';

        } elseif ($_FILES['image']['size'] > 5242880) {

            $err = 'Image must be under 5MB.';

        } else {

            $dir = __DIR__ . '/../assets/uploads/';

            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            $fn = uniqid('prod_') . '.' . $ext;

            if (move_uploaded_file(
                $_FILES['image']['tmp_name'],
                $dir . $fn
            )) {
                $image = 'assets/uploads/' . $fn;
            } else {
                $err = 'Upload failed.';
            }
        }
    }

    /* Save product */
    if (!$err) {

        if ($edit) {

            $s = $conn->prepare(
                'UPDATE products
                 SET category_id = ?,
                     name = ?,
                     description = ?,
                     price = ?,
                     discount_price = ?,
                     stock = ?,
                     image = ?,
                     is_new = ?,
                     is_best_seller = ?,
                     status = ?
                 WHERE id = ?'
            );

            $s->bind_param(
                'issddisiisi',
                $cat,
                $name,
                $desc,
                $price,
                $disc,
                $stock,
                $image,
                $new,
                $best,
                $status,
                $id
            );

        } else {

            $s = $conn->prepare(
                'INSERT INTO products
                (
                    category_id,
                    name,
                    description,
                    price,
                    discount_price,
                    stock,
                    image,
                    is_new,
                    is_best_seller,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );

            $s->bind_param(
                'issddisiis',
                $cat,
                $name,
                $desc,
                $price,
                $disc,
                $stock,
                $image,
                $new,
                $best,
                $status
            );
        }

        if ($s->execute()) {

            header('Location: products.php');
            exit;

        } else {

            $err = $s->error;
        }
    }
}

/* Categories */
$cats = $conn->query(
    'SELECT * FROM categories ORDER BY name'
);

$pageTitle = $edit ? 'Edit Product' : 'Add Product';

require '../includes/header.php';
?>

<div class="container py-4">

    <h1 class="section-title">
        <?= $edit ? 'Edit' : 'Add' ?> Product
    </h1>

    <?php if ($err): ?>

        <div class="alert alert-danger">
            <?= e($err) ?>
        </div>

    <?php endif; ?>

    <form
        class="card p-4"
        method="post"
        enctype="multipart/form-data"
    >

        <div class="row">

            <div class="col-md-8">

                <input
                    class="form-control mb-3"
                    name="name"
                    placeholder="Product name"
                    value="<?= e($p['name']) ?>"
                    required
                >

                <textarea
                    class="form-control mb-3"
                    name="description"
                    placeholder="Description"
                    rows="5"
                ><?= e($p['description']) ?></textarea>

                <div class="row">

                    <div class="col">
                        <input
                            class="form-control mb-3"
                            type="number"
                            step=".01"
                            name="price"
                            placeholder="Price"
                            value="<?= e($p['price']) ?>"
                            required
                        >
                    </div>

                    <div class="col">
                        <input
                            class="form-control mb-3"
                            type="number"
                            step=".01"
                            name="discount_price"
                            placeholder="Discount price"
                            value="<?= e($p['discount_price']) ?>"
                        >
                    </div>

                    <div class="col">
                        <input
                            class="form-control mb-3"
                            type="number"
                            name="stock"
                            placeholder="Stock"
                            value="<?= e($p['stock']) ?>"
                        >
                    </div>

                </div>

                <select
                    class="form-select mb-3"
                    name="category_id"
                    required
                >

                    <option value="">
                        Select category
                    </option>

                    <?php while ($c = $cats->fetch_assoc()): ?>

                        <option
                            value="<?= $c['id'] ?>"
                            <?= $p['category_id'] == $c['id'] ? 'selected' : '' ?>
                        >
                            <?= e($c['name']) ?>
                        </option>

                    <?php endwhile; ?>

                </select>

                <label>
                    <input
                        type="checkbox"
                        name="is_new"
                        <?= $p['is_new'] ? 'checked' : '' ?>
                    >
                    New Arrival
                </label>

                <br>

                <label>
                    <input
                        type="checkbox"
                        name="is_best_seller"
                        <?= $p['is_best_seller'] ? 'checked' : '' ?>
                    >
                    Best Seller
                </label>

                <select
                    class="form-select mt-3"
                    name="status"
                >

                    <option
                        value="active"
                        <?= $p['status'] === 'active' ? 'selected' : '' ?>
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        <?= $p['status'] === 'inactive' ? 'selected' : '' ?>
                    >
                        Inactive
                    </option>

                </select>

            </div>

            <div class="col-md-4">

                <label>Product Image</label>

                <input
                    class="form-control mt-2"
                    type="file"
                    name="image"
                    accept="image/*"
                >

                <?php if (!empty($p['image'])): ?>

                    <img
                        class="preview mt-3"
                        src="../<?= e(img($p['image'])) ?>"
                        style="max-width: 100%;"
                    >

                <?php endif; ?>

            </div>

        </div>

        <button
            class="btn btn-bold mt-3"
            type="submit"
        >
            <?= $edit ? 'UPDATE' : 'ADD' ?> PRODUCT
        </button>

        <a
            class="btn btn-outline-dark mt-3"
            href="products.php"
        >
            Cancel
        </a>

    </form>

</div>

<?php require '../includes/footer.php'; ?>