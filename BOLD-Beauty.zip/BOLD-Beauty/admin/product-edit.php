<?php

require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: products.php');
    exit;
}

/* Get existing product */
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$p = $result->fetch_assoc();

if (!$p) {
    die("Product not found.");
}

$err = '';

/* Update product */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);

    $disc = ($_POST['discount_price'] ?? '') === ''
        ? null
        : (float)$_POST['discount_price'];

    $stock = (int)($_POST['stock'] ?? 0);
    $cat = (int)($_POST['category_id'] ?? 0);

    $new = isset($_POST['is_new']) ? 1 : 0;
    $best = isset($_POST['is_best_seller']) ? 1 : 0;

    $status = $_POST['status'] ?? 'active';

    /* Keep old image */
    $image = $p['image'];

    /* Validation */
    if ($name === '' || $price <= 0 || $cat <= 0) {

        $err = 'Name, price and category are required.';
    }

    /* Upload new image */
    if (!$err && !empty($_FILES['image']['name'])) {

        $ext = strtolower(
            pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION)
        );

        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {

            $err = 'Use JPG, PNG, GIF or WEBP.';

        } elseif ($_FILES['image']['size'] > 5242880) {

            $err = 'Image must be under 5MB.';

        } else {

            $dir = __DIR__ . '/../assets/uploads/';

            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            $fn = uniqid('prod_') . '.' . $ext;

            if (
                move_uploaded_file(
                    $_FILES['image']['tmp_name'],
                    $dir . $fn
                )
            ) {

                $image = 'assets/uploads/' . $fn;

            } else {

                $err = 'Upload failed.';
            }
        }
    }

    /* Update database */
    if (!$err) {

        $stmt = $conn->prepare("
            UPDATE products
            SET
                category_id = ?,
                name = ?,
                description = ?,
                price = ?,
                discount_price = ?,
                stock = ?,
                image = ?,
                is_new = ?,
                is_bestseller = ?,
                status = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "issddisiisi",
            $cat,
            $name,
            $desc,
            $price,
            $disc,
            $stock,
            $image,
            $new,
            $best,
            $status,
            $id
        );

        if ($stmt->execute()) {

            header('Location: products.php');
            exit;

        } else {

            $err = $stmt->error;
        }
    }

    /* Update displayed values after validation/upload */
    $p['name'] = $name;
    $p['description'] = $desc;
    $p['price'] = $price;
    $p['discount_price'] = $disc;
    $p['stock'] = $stock;
    $p['category_id'] = $cat;
    $p['is_new'] = $new;
    $p['is_bestseller'] = $best;
    $p['status'] = $status;
    $p['image'] = $image;
}

/* Categories */
$cats = $conn->query("
    SELECT *
    FROM categories
    ORDER BY name
");

$pageTitle = 'Edit Product';

require_once __DIR__ . '/includes/header.php';

?>

<div class="container py-5">

    <h1 class="section-title mb-4">
        Edit Product
    </h1>

    <?php if ($err): ?>

        <div class="alert alert-danger">
            <?= e($err) ?>
        </div>

    <?php endif; ?>

    <form
        class="card p-4"
        method="post"
        enctype="multipart/form-data"
    >

        <div class="row">

            <div class="col-md-8">

                <input
                    class="form-control mb-3"
                    name="name"
                    placeholder="Product name"
                    value="<?= e($p['name']) ?>"
                    required
                >

                <textarea
                    class="form-control mb-3"
                    name="description"
                    placeholder="Description"
                    rows="5"
                ><?= e($p['description']) ?></textarea>

                <div class="row">

                    <div class="col">

                        <input
                            class="form-control mb-3"
                            type="number"
                            step="0.01"
                            name="price"
                            placeholder="Price"
                            value="<?= e($p['price']) ?>"
                            required
                        >

                    </div>

                    <div class="col">

                        <input
                            class="form-control mb-3"
                            type="number"
                            step="0.01"
                            name="discount_price"
                            placeholder="Discount price"
                            value="<?= e($p['discount_price']) ?>"
                        >

                    </div>

                    <div class="col">

                        <input
                            class="form-control mb-3"
                            type="number"
                            name="stock"
                            placeholder="Stock"
                            value="<?= e($p['stock']) ?>"
                        >

                    </div>

                </div>

                <select
                    class="form-select mb-3"
                    name="category_id"
                    required
                >

                    <option value="">
                        Select category
                    </option>

                    <?php while ($c = $cats->fetch_assoc()): ?>

                        <option
                            value="<?= (int)$c['id'] ?>"
                            <?= $p['category_id'] == $c['id'] ? 'selected' : '' ?>
                        >
                            <?= e($c['name']) ?>
                        </option>

                    <?php endwhile; ?>

                </select>

                <label>
                    <input
                        type="checkbox"
                        name="is_new"
                        <?= $p['is_new'] ? 'checked' : '' ?>
                    >
                    New Arrival
                </label>

                <br>

                <label>
                    <input
                        type="checkbox"
                        name="is_best_seller"
                        <?= $p['is_best_seller'] ? 'checked' : '' ?>
                    >
                    Best Seller
                </label>

                <select
                    class="form-select mt-3"
                    name="status"
                >

                    <option
                        value="active"
                        <?= $p['status'] === 'active' ? 'selected' : '' ?>
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        <?= $p['status'] === 'inactive' ? 'selected' : '' ?>
                    >
                        Inactive / Discontinued
                    </option>

                </select>

            </div>

            <div class="col-md-4">

                <label class="form-label">
                    Product Image
                </label>

                <input
                    class="form-control mt-2"
                    type="file"
                    name="image"
                    accept="image/*"
                >

                <?php if (!empty($p['image'])): ?>

                    <img
                        class="img-fluid mt-3 rounded"
                        src="../<?= e(img($p['image'])) ?>"
                        alt="<?= e($p['name']) ?>"
                        style="
                            width:100%;
                            max-height:350px;
                            object-fit:cover;
                        "
                    >

                    <small class="text-muted d-block mt-2">
                        Choose a new image only if you want to replace the current image.
                    </small>

                <?php endif; ?>

            </div>

        </div>

        <div class="mt-4">

            <button
                type="submit"
                class="btn btn-bold"
            >
                UPDATE PRODUCT
            </button>

            <a
                href="products.php"
                class="btn btn-outline-dark"
            >
                Cancel
            </a>

        </div>

    </form>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>