<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once "../includes/database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {

        $error = "Please enter email and password.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id, name, email, password, role
             FROM users
             WHERE email = ?
             AND role = 'admin'
             LIMIT 1"
        );

        if (!$stmt) {

            $error = "Database error: " . $conn->error;

        } else {

            $stmt->bind_param("s", $email);
            $stmt->execute();

            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {

                $admin = $result->fetch_assoc();

                if (password_verify($password, $admin["password"])) {

                    $_SESSION["admin_id"] = $admin["id"];
                    $_SESSION["admin_name"] = $admin["name"];
                    $_SESSION["admin_email"] = $admin["email"];
                    $_SESSION["role"] = "admin";

                    header("Location: index.php");
                    exit;

                } else {

                    $error = "Invalid email or password.";

                }

            } else {

                $error = "Admin account not found.";

            }

            $stmt->close();
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Login — BOLD Beauty</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    min-height: 100vh;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #f8f4f0;

    font-family: Arial, sans-serif;
}

.login-wrapper {

    width: 100%;

    max-width: 430px;

    padding: 20px;
}

.login-box {

    background: #ffffff;

    padding: 40px;

    border-radius: 16px;

    box-shadow: 0 15px 45px rgba(0,0,0,0.10);
}

.brand {

    text-align: center;

    font-family: Georgia, serif;

    font-size: 32px;

    font-weight: bold;

    color: #222;

    margin-bottom: 5px;
}

.brand span {

    color: #8b1735;
}

.subtitle {

    text-align: center;

    color: #777;

    margin-bottom: 30px;
}

.form-label {

    font-weight: 600;

    color: #333;
}

.form-control {

    height: 50px;

    border: 1px solid #ddd;

    border-radius: 7px;
}

.form-control:focus {

    border-color: #8b1735;

    box-shadow: 0 0 0 0.2rem rgba(139,23,53,.12);
}

.btn-login {

    width: 100%;

    height: 50px;

    border: none;

    border-radius: 7px;

    background: #222;

    color: white;

    font-weight: bold;

    letter-spacing: 1px;

    cursor: pointer;
}

.btn-login:hover {

    background: #8b1735;
}

.back-link {

    display: block;

    text-align: center;

    margin-top: 25px;

    color: #8b1735;

    text-decoration: none;
}

.back-link:hover {

    text-decoration: underline;
}

.admin-label {

    text-align: center;

    font-size: 12px;

    letter-spacing: 2px;

    color: #8b1735;

    font-weight: bold;

    margin-bottom: 8px;
}

</style>

</head>

<body>

<div class="login-wrapper">

    <div class="login-box">

        <div class="admin-label">
            BOLD BEAUTY
        </div>

        <div class="brand">
            BOLD<span>Beauty</span>
        </div>

        <div class="subtitle">
            Admin Panel Login
        </div>


        <?php if ($error !== ""): ?>

            <div class="alert alert-danger">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <form method="POST" action="">

            <div class="mb-3">

                <label class="form-label">
                    Admin Email
                </label>

                <input
                    type="email"
                    name="email"
                    class="form-control"
                    placeholder="admin@boldbeauty.com"
                    required
                >

            </div>


            <div class="mb-4">

                <label class="form-label">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    class="form-control"
                    placeholder="Enter password"
                    required
                >

            </div>


            <button
                type="submit"
                class="btn-login"
            >
                LOGIN
            </button>

        </form>


        <a
            href="../index.php"
            class="back-link"
        >
            ← Back to BOLD Beauty
        </a>

    </div>

</div>

</body>

</html>