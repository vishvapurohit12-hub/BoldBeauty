<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__, 2) . '/includes/functions.php';

needAdmin();

?>

<!doctype html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= e($pageTitle ?? 'Admin') ?> — BOLD Beauty
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f8f4f0;
            font-family: Arial, sans-serif;
        }

        .adminbar {
            background: #222;
            min-height: 65px;
        }

        .brand {
            font-family: Georgia, serif;
            font-size: 28px;
            font-weight: bold;
            color: white !important;
        }

        .brand span {
            color: #8b1735;
        }

        .admin-side {
            background: #fff;
            min-height: calc(100vh - 65px);
            padding: 25px 15px;
            border-right: 1px solid #ddd;
        }

        .admin-side a {
            display: block;
            padding: 12px 15px;
            margin-bottom: 8px;
            color: #333;
            text-decoration: none;
            border-radius: 6px;
        }

        .admin-side a:hover {
            background: #f3e6e9;
            color: #8b1735;
        }

        .admin-side a.active {
            background: #8b1735;
            color: white;
        }

        .admin-content {
            padding: 30px;
        }

        .admin-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 25px rgba(0,0,0,.06);
        }

        .btn-bold {
            background: #8b1735;
            color: white;
            border: none;
        }

        .btn-bold:hover {
            background: #6f1029;
            color: white;
        }

    </style>

</head>

<body>


<!-- ADMIN NAVBAR -->

<nav class="navbar adminbar">

    <div class="container-fluid px-4">

        <a
            class="navbar-brand brand"
            href="index.php"
        >
            BOLD<span>Beauty</span>
        </a>


        <div class="text-white">

            Hi,
            <?= e($_SESSION['admin_name'] ?? 'Admin') ?>


            <a
                class="btn btn-sm btn-outline-light ms-3"
                href="logout.php"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<!-- ADMIN LAYOUT -->

<div class="container-fluid">

    <div class="row">


        <!-- SIDEBAR -->

        <aside class="col-md-2 admin-side">

            <a href="index.php">
                Dashboard
            </a>

            <a href="products.php">
                Products
            </a>

            <a href="product-add.php">
                Add Product
            </a>

            <a href="categories.php">
                Categories
            </a>

            <a href="orders.php">
                Orders
            </a>

            <a href="customers.php">
                Customers
            </a>

            <a
                href="../index.php"
                target="_blank"
            >
                View Store
            </a>

        </aside>


        <!-- MAIN CONTENT -->

        <main class="col-md-10 admin-content">