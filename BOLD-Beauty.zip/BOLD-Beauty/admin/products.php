<?php

require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';

$pageTitle = 'Products';

require_once __DIR__ . '/includes/header.php';

/* Delete product */
if (isset($_GET['delete'])) {

    $id = (int)$_GET['delete'];

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    header("Location: products.php");
    exit;
}

/* Get products */
$rs = $conn->query("
    SELECT 
        p.*,
        c.name AS category_name
    FROM products p
    LEFT JOIN categories c 
        ON p.category_id = c.id
    ORDER BY p.id DESC
");

?>

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h1 class="section-title mb-0">
            Products
        </h1>

        <a href="product-add.php" class="btn btn-bold">
            + ADD PRODUCT
        </a>

    </div>

    <div class="card border-0 shadow-sm">

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($rs && $rs->num_rows > 0): ?>

                    <?php while ($p = $rs->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?= (int)$p['id'] ?>
                            </td>

                            <td>

                                <?php if (!empty($p['image'])): ?>

                                    <img
                                        src="../<?= htmlspecialchars($p['image']) ?>"
                                        width="70"
                                        height="70"
                                        style="object-fit:cover;border-radius:8px;"
                                    >

                                <?php else: ?>

                                    <span class="text-muted">
                                        No image
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>
                                <strong>
                                    <?= htmlspecialchars($p['name']) ?>
                                </strong>
                            </td>

                            <td>
                                <?= htmlspecialchars($p['category_name'] ?? '—') ?>
                            </td>

                            <td>
                                ₹<?= number_format((float)$p['price'], 2) ?>
                            </td>

                            <td>
                                <?= (int)$p['stock'] ?>
                            </td>

                            <td>

                                <?php if (($p['status'] ?? 'active') === 'active'): ?>

                                    <span class="badge bg-success">
                                        Active
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-secondary">
                                        Inactive
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>
                                <a
                                    href="product-edit.php?id=<?= (int)$p['id'] ?>"
                                    class="btn btn-sm btn-outline-dark"
                                >
                                    Edit
                                </a>

                                <a
                                    href="products.php?delete=<?= (int)$p['id'] ?>"
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('Delete this product?');"
                                >
                                    Delete
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="8" class="text-center py-5">
                            No products found.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>