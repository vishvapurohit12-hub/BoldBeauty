<?php

require '../includes/database.php';
require '../includes/functions.php';

$pageTitle = 'Dashboard';

require '../includes/header.php';

/* Products */
$a = $conn->query(
    "SELECT COUNT(*) AS n FROM products"
)->fetch_assoc()['n'];

/* Customers */
$b = $conn->query(
    "SELECT COUNT(*) AS n FROM users WHERE role = 'customer'"
)->fetch_assoc()['n'];

/* Orders */
$c = $conn->query(
    "SELECT COUNT(*) AS n FROM orders"
)->fetch_assoc()['n'];

/* Revenue */
$d = $conn->query(
    "SELECT COALESCE(SUM(total), 0) AS n
     FROM orders"
)->fetch_assoc()['n'];
?>

<div class="container py-4">

    <h1 class="section-title">Admin Dashboard</h1>

    <div class="row g-4 mt-2">

        <?php
        $cards = [
            ['Products', $a, 'products.php'],
            ['Customers', $b, 'customers.php'],
            ['Orders', $c, 'orders.php'],
            ['Revenue', '₹' . number_format($d, 2), 'orders.php']
        ];
        ?>

        <?php foreach ($cards as $x): ?>

            <div class="col-md-3">

                <div class="card p-4">

                    <small><?= e($x[0]) ?></small>

                    <h2><?= e($x[1]) ?></h2>

                    <a href="<?= e($x[2]) ?>">
                        Manage →
                    </a>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

    <div class="card p-4 mt-4">

        <h4>Quick Actions</h4>

        <a
            class="btn btn-bold"
            href="product-add.php"
        >
            + Add Product
        </a>

    </div>

</div>

<?php require '../includes/footer.php'; ?>