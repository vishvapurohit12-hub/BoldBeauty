BOLD Beauty Full Stack PHP/MySQL

Install: extract to C:\xampp2\htdocs\BOLD-Beauty (or C:\xampp\htdocs\BOLD-Beauty), start Apache/MySQL, open http://localhost/BOLD-Beauty/setup.php once.
Admin: admin@boldbeauty.com / Admin@123
Customer: create account at signup.php.
Database: bold_beauty. Product uploads go to assets/uploads/.
